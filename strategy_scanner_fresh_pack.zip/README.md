# Strategy Scanner: Clean Setup
Ready-to-run with selector, charts, and timeframe toggle.

# Clean app.py with strategy selector, timeframe toggle, chart viewer, backtest output

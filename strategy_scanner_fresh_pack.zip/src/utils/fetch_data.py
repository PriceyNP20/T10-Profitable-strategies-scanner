def get_data(symbol, tf): return []

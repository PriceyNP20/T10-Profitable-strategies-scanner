def trend_following_strategy(df): return df

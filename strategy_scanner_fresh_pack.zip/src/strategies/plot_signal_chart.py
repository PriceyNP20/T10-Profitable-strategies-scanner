def plot_signal_chart(df): return None

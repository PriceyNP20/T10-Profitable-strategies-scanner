def momentum_strategy(df): return df

def options_selling_strategy(df): return df

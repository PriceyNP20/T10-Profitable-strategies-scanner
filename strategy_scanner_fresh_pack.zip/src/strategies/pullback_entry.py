def pullback_entry_strategy(df): return df

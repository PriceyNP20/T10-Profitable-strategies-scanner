def breakout_strategy(df): return df

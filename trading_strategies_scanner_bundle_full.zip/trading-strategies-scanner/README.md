# Trading Strategies Scanner

A Streamlit app showcasing 10 profitable trading strategies using live data.
def options_selling_stub():
    return "Options strategies not implemented in spot data; use options backtester."
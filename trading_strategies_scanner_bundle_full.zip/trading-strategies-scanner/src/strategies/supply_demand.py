def supply_demand_strategy(df):
    df['Demand_Zone'] = df['low'].rolling(5).min()
    df['Signal'] = df['close'] <= df['Demand_Zone']
    return df[df['Signal']]